document.addEventListener('DOMContentLoaded', () => {
    const nombreInput = document.getElementById('nombre');
    const rubroInput = document.getElementById('rubro');
    const precioInput = document.getElementById('precio');
    const stockInput = document.getElementById('stock');
    const agregarBtn = document.getElementById('agregarBtn');
    const inventoryBody = document.getElementById('inventoryBody');
    const filtroRubro = document.getElementById('filtroRubro');
    const buscarNombreInput = document.getElementById('buscarNombre');

    const editModal = document.getElementById('editModal');
    const editIndexInput = document.getElementById('editIndex');
    const editNombreInput = document.getElementById('editNombre');
    const editRubroInput = document.getElementById('editRubro');
    const editPrecioInput = document.getElementById('editPrecio');
    const editStockInput = document.getElementById('editStock');
    const guardarBtn = document.getElementById('guardarBtn');
    const closeEditModal = editModal.querySelector('.close-button');

    const sellModal = document.getElementById('sellModal');
    const sellIndexInput = document.getElementById('sellIndex');
    const sellQuantityInput = document.getElementById('sellQuantity');
    const venderBtn = document.getElementById('venderBtn');
    const closeSellModal = sellModal.querySelector('.close-sell-button');
    const sellItemNameDisplay = document.getElementById('sellItemName');

    let inventario = cargarInventario();
    actualizarTablaInventario(inventario);
    cargarFiltroRubros(inventario);

    // Función para guardar el inventario en localStorage
    function guardarInventario() {
        localStorage.setItem('inventario', JSON.stringify(inventario));
    }

    // Función para cargar el inventario desde localStorage
    function cargarInventario() {
        const almacenado = localStorage.getItem('inventario');
        return almacenado ? JSON.parse(almacenado) : [];
    }

    // Función para validar los campos del formulario de agregar/editar
    function validarArticulo(nombre, rubro, precio, stock) {
        if (!nombre.trim()) {
            alert('El nombre del artículo es obligatorio.');
            return false;
        }
        if (!rubro.trim()) {
            alert('El rubro del artículo es obligatorio.');
            return false;
        }
        if (isNaN(precio) || precio < 0) {
            alert('El precio debe ser un número válido mayor o igual a 0.');
            return false;
        }
        if (isNaN(stock) || stock < 0 || !Number.isInteger(stock)) {
            alert('El stock debe ser un número entero válido mayor o igual a 0.');
            return false;
        }
        return true;
    }

    // Función para agregar un nuevo artículo al inventario
    function agregarArticulo() {
        const nombre = nombreInput.value.trim();
        const rubro = rubroInput.value.trim();
        const precio = parseFloat(precioInput.value);
        const stock = parseInt(stockInput.value);

        if (validarArticulo(nombre, rubro, precio, stock)) {
            const nuevoArticulo = { nombre, rubro, precio, stock };
            inventario.push(nuevoArticulo);
            guardarInventario();
            actualizarTablaInventario(filtrarInventario()); // Re-renderizar con los filtros actuales
            cargarFiltroRubros(inventario); // Asegurar que los filtros estén actualizados
            limpiarFormulario();
        }
    }

    // Función para limpiar el formulario después de agregar un artículo
    function limpiarFormulario() {
        nombreInput.value = '';
        rubroInput.value = '';
        precioInput.value = '';
        stockInput.value = '';
    }

    // Función para crear los botones de acción (editar, eliminar, vender)
    function crearBotonesAccion(index) {
        const acciones = document.createElement('div');
        acciones.classList.add('action-buttons');

        const editarBtn = document.createElement('button');
        editarBtn.textContent = 'Editar';
        editarBtn.classList.add('edit-btn');
        editarBtn.addEventListener('click', () => mostrarModalEditar(index));

        const eliminarBtn = document.createElement('button');
        eliminarBtn.textContent = 'Eliminar';
        eliminarBtn.classList.add('delete-btn');
        eliminarBtn.addEventListener('click', () => eliminarArticulo(index));

        const venderBtn = document.createElement('button');
        venderBtn.textContent = 'Vender';
        venderBtn.classList.add('sell-btn');
        venderBtn.addEventListener('click', () => mostrarModalVender(index));

        acciones.appendChild(editarBtn);
        acciones.appendChild(eliminarBtn);
        acciones.appendChild(venderBtn);
        return acciones;
    }

    // Función para actualizar la tabla del inventario en el HTML
    function actualizarTablaInventario(listaInventario) {
        inventoryBody.innerHTML = '';
        listaInventario.forEach((articulo, index) => {
            const row = inventoryBody.insertRow();
            row.classList.toggle('stock-bajo', articulo.stock < 5); // Alerta de stock bajo

            const nombreCell = row.insertCell();
            const rubroCell = row.insertCell();
            const precioCell = row.insertCell();
            const stockCell = row.insertCell();
            const accionesCell = row.insertCell();

            nombreCell.textContent = articulo.nombre;
            rubroCell.textContent = articulo.rubro;
            precioCell.textContent = `$${articulo.precio.toFixed(2)}`;
            stockCell.textContent = articulo.stock;
            accionesCell.appendChild(crearBotonesAccion(inventario.indexOf(articulo))); // Pasar el índice correcto
        });
    }

    // Función para cargar las opciones del filtro de rubros
    function cargarFiltroRubros(listaInventario) {
        const rubros = [...new Set(listaInventario.map(item => item.rubro))].sort(); // Obtener rubros únicos y ordenarlos
        filtroRubro.innerHTML = '<option value="">Todos los Rubros</option>';
        rubros.forEach(rubro => {
            const option = document.createElement('option');
            option.value = rubro;
            option.textContent = rubro;
            filtroRubro.appendChild(option);
        });
    }

    // Evento para el botón "Agregar Artículo"
    agregarBtn.addEventListener('click', agregarArticulo);

    // **Funcionalidad de Editar Artículo**
    function mostrarModalEditar(index) {
        const articulo = inventario[index];
        editIndexInput.value = index;
        editNombreInput.value = articulo.nombre;
        editRubroInput.value = articulo.rubro;
        editPrecioInput.value = articulo.precio;
        editStockInput.value = articulo.stock;
        editModal.style.display = 'block';
    }

    guardarBtn.addEventListener('click', () => {
        const index = parseInt(editIndexInput.value);
        const nombre = editNombreInput.value.trim();
        const rubro = editRubroInput.value.trim();
        const precio = parseFloat(editPrecioInput.value);
        const stock = parseInt(editStockInput.value);

        if (validarArticulo(nombre, rubro, precio, stock)) {
            inventario[index] = { nombre, rubro, precio, stock };
            guardarInventario();
            actualizarTablaInventario(filtrarInventario()); // Re-renderizar con los filtros actuales
            cargarFiltroRubros(inventario); // Asegurar que los filtros estén actualizados
            editModal.style.display = 'none';
        }
    });

    closeEditModal.addEventListener('click', () => {
        editModal.style.display = 'none';
    });

    window.addEventListener('click', (event) => {
        if (event.target == editModal) {
            editModal.style.display = 'none';
        }
        if (event.target == sellModal) {
            sellModal.style.display = 'none';
        }
    });

    // **Funcionalidad de Eliminar Artículo**
    function eliminarArticulo(index) {
        if (confirm('¿Estás seguro de que quieres eliminar este artículo?')) {
            inventario.splice(index, 1);
            guardarInventario();
            actualizarTablaInventario(filtrarInventario()); // Re-renderizar con los filtros actuales
            cargarFiltroRubros(inventario); // Asegurar que los filtros estén actualizados
        }
    }

    // **Funcionalidad de Filtrado por Rubro**
    filtroRubro.addEventListener('change', () => {
        actualizarTablaInventario(filtrarInventario());
    });

    // **Funcionalidad de Búsqueda por Nombre**
    buscarNombreInput.addEventListener('input', () => {
        actualizarTablaInventario(filtrarInventario());
    });

    // **Función para filtrar el inventario basado en los filtros**
    function filtrarInventario() {
        const filtroRubroValor = filtroRubro.value;
        const buscarNombreValor = buscarNombreInput.value.toLowerCase().trim();

        return inventario.filter(articulo => {
            const filtroRubroCoincide = !filtroRubroValor || articulo.rubro === filtroRubroValor;
            const buscarNombreCoincide = !buscarNombreValor || articulo.nombre.toLowerCase().includes(buscarNombreValor);
            return filtroRubroCoincide && buscarNombreCoincide;
        });
    }

    // **Funcionalidad de Vender Artículo y Actualizar Stock**
    function mostrarModalVender(index) {
        const articulo = inventario[index];
        sellIndexInput.value = index;
        sellItemNameDisplay.textContent = articulo.nombre;
        sellQuantityInput.max = articulo.stock;
        sellQuantityInput.value = 1; // Resetear la cantidad cada vez que se abre el modal
        sellModal.style.display = 'block';
    }

    venderBtn.addEventListener('click', () => {
        const index = parseInt(sellIndexInput.value);
        const cantidad = parseInt(sellQuantityInput.value);

        if (!isNaN(cantidad) && cantidad > 0 && cantidad <= inventario[index].stock) {
            inventario[index].stock -= cantidad;
            guardarInventario();
            actualizarTablaInventario(filtrarInventario()); // Re-renderizar con los filtros actuales
            sellModal.style.display = 'none';
        } else {
            alert('Por favor, ingresa una cantidad válida para vender.');
        }
    });

    closeSellModal.addEventListener('click', () => {
        sellModal.style.display = 'none';
    });
});